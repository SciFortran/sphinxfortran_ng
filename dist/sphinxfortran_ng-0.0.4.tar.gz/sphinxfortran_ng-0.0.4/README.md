# sphinxfortran_ng

[![PyPI](https://img.shields.io/pypi/v/sphinxfortran-ng.svg)](https://pypi.org/project/sphinxfortran-ng)

An improved version of the original sphinx-fortran python module.

This code is based on the following original software:

- [sphinx-fortran](https://gitlab.com/l_sim/sphinx-fortran), on the "l_sim" working branch
- [sphinx-fortran](https://pypi.org/project/sphinx-fortran/), original sphinx-fortran project
- [crackfortran](https://github.com/numpy/numpy/tree/main/numpy/f2py) from the Numpy/f2py python module


